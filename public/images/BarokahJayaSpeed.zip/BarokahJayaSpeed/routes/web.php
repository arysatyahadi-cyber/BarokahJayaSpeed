<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\BookingController;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/sparepart', fn() => view('sparepart'));
Route::get('/booking', [BookingController::class, 'create'])->name('booking.create');
Route::post('/booking', [BookingController::class, 'store'])->name('booking.store');
Route::get('/history', [BookingController::class, 'index'])->name('booking.index');
Route::post('/booking/{id}/update-status', [BookingController::class, 'updateStatus'])->name('booking.updateStatus');
Route::get('/hitung-cc', fn() => view('hitung-cc'));
