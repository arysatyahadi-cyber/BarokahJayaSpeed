<?php $__env->startSection('title', 'Sparepart — Barokah Jaya Speed'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="section-title">Sparepart Premium</h2>

<div class="grid-container">
  <?php $__currentLoopData = range(1, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="spare-card">
    <img src="https://via.placeholder.com/150" alt="Sparepart <?php echo e($i); ?>">
    <h4>Sparepart <?php echo e($i); ?></h4>
    <p>Rp <?php echo e(number_format(150000 * $i, 0, ',', '.')); ?></p>
    <button class="btn-red">Detail</button>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BarokahJayaSpeed\resources\views/sparepart.blade.php ENDPATH**/ ?>