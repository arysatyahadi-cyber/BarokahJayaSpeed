<?php $__env->startSection('title', 'Home - Barokah Jaya Speed'); ?>

<?php $__env->startSection('content'); ?>
<section class="hero">
  <div class="hero-text">
    <h1>Barokah Jaya Speed</h1>
    <p>Bengkel Racing & Service Profesional — Cepat, Presisi, Berkelas!</p>
    <a href="<?php echo e(url('/booking')); ?>" class="btn-red">Booking Sekarang</a>
  </div>
</section>

<section class="history-preview">
  <h2 class="section-title">Riwayat Servis Terbaru</h2>
  <div class="history-card">
    <table>
      <thead>
        <tr>
          <th>Nama Pelanggan</th>
          <th>Motor</th>
          <th>No. Polisi</th>
          <th>Keluhan</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($booking->customer_name); ?></td>
          <td><?php echo e($booking->motor); ?></td>
          <td><?php echo e($booking->nopol); ?></td>
          <td><?php echo e($booking->notes); ?></td>
          <td>
            <span class="status <?php echo e(strtolower(str_replace(' ', '-', $booking->status))); ?>">
              <?php echo e($booking->status); ?>

            </span>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="5" style="text-align:center;">Belum ada riwayat booking.</td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BarokahJayaSpeed\resources\views/home.blade.php ENDPATH**/ ?>