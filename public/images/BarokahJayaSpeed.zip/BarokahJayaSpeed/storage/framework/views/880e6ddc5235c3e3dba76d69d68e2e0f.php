
<?php $__env->startSection('title', 'Hitung CC — Barokah Jaya Speed'); ?>

<?php $__env->startSection('content'); ?>
<div class="cc-card">
  <h2>Hitung Kapasitas Mesin (CC)</h2>
  <form>
    <input type="number" id="bore" placeholder="Diameter (mm)">
    <input type="number" id="stroke" placeholder="Langkah (mm)">
    <input type="number" id="cylinder" placeholder="Jumlah Silinder">
    <button type="button" class="btn-red" onclick="hitungCC()">Hitung</button>
  </form>
  <h3 id="hasil"></h3>
</div>

<script>
function hitungCC() {
  let bore = document.getElementById('bore').value;
  let stroke = document.getElementById('stroke').value;
  let cyl = document.getElementById('cylinder').value;
  let cc = (3.14 / 4) * bore * bore * stroke * cyl / 1000;
  document.getElementById('hasil').innerText = `Hasil: ${cc.toFixed(2)} cc`;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BarokahJayaSpeed\resources\views/hitung-cc.blade.php ENDPATH**/ ?>