<?php $__env->startSection('title', 'Booking Servis - Barokah Jaya Speed'); ?>

<?php $__env->startSection('content'); ?>
<section class="booking-page">
  <h2 class="section-title">Form Booking Servis</h2>

  <form action="<?php echo e(route('booking.store')); ?>" method="POST" class="booking-form">
    <?php echo csrf_field(); ?>

    <div class="booking-grid">
      <!-- === DATA PELANGGAN === -->
      <div class="booking-card">
        <h3>Data Pelanggan</h3>
        <div class="form-group">
          <label>Nama Pelanggan</label>
          <input type="text" name="customer_name" placeholder="Masukkan nama lengkap" required>
        </div>
        <div class="form-group">
          <label>No. HP / WhatsApp</label>
          <input type="text" name="phone" placeholder="Contoh: 081234567890" required>
        </div>
        <div class="form-group">
          <label>Alamat</label>
          <textarea name="address" placeholder="Alamat lengkap..." rows="3"></textarea>
        </div>
      </div>

      <!-- === DATA KENDARAAN === -->
      <div class="booking-card">
        <h3>Data Kendaraan</h3>
        <div class="form-group">
          <label>Nama Motor</label>
          <input type="text" name="motor" placeholder="Contoh: Yamaha R15, Honda Supra X" required>
        </div>
        <div class="form-group">
          <label>No. Polisi</label>
          <input type="text" name="nopol" placeholder="Contoh: AB 1234 XY" required>
        </div>
        <div class="form-group">
          <label>Keluhan / Servis</label>
          <textarea name="notes" placeholder="Tulis keluhan atau servis yang diinginkan..." rows="3"></textarea>
        </div>
      </div>
    </div>

    <div class="booking-submit">
      <button type="submit" class="btn-red">🚀 Kirim Booking</button>
    </div>
  </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BarokahJayaSpeed\resources\views/booking.blade.php ENDPATH**/ ?>