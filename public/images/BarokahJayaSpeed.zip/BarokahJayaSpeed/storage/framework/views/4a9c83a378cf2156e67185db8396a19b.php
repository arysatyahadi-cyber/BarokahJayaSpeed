<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'Barokah Jaya Speed'); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
  <header class="navbar">
    <div class="logo">BAROKAH <span>JAYA SPEED</span></div>
    <nav>
      <a href="<?php echo e(url('/')); ?>" class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">Home</a>
      <a href="<?php echo e(url('/sparepart')); ?>" class="<?php echo e(Request::is('sparepart') ? 'active' : ''); ?>">Sparepart</a>
      <a href="<?php echo e(url('/booking')); ?>" class="<?php echo e(Request::is('booking') ? 'active' : ''); ?>">Booking</a>
      <a href="<?php echo e(url('/history')); ?>" class="<?php echo e(Request::is('history') ? 'active' : ''); ?>">History</a>
      <a href="<?php echo e(url('/hitung-cc')); ?>" class="<?php echo e(Request::is('hitung-cc') ? 'active' : ''); ?>">Hitung CC</a>
    </nav>
  </header>

  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <footer class="footer">
    <p>© 2025 Barokah Jaya Speed — Racing with Elegance ⚡</p>
  </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BarokahJayaSpeed\resources\views/layouts/layout.blade.php ENDPATH**/ ?>