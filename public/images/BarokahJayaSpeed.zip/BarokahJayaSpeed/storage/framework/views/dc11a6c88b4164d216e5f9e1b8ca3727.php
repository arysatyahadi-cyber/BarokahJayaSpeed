<?php $__env->startSection('title', 'History — Barokah Jaya Speed'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="section-title">History Booking Terbaru</h2>
<div class="history-card">
  <table>
    <thead>
      <tr>
        <th>Nama</th>
        <th>Motor</th>
        <th>No. Polisi</th>
        <th>Keluhan</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($b->nama); ?></td>
        <td><?php echo e($b->motor); ?></td>
        <td><?php echo e($b->nopol); ?></td>
        <td><?php echo e($b->keluhan); ?></td>
        <td><?php echo e($b->status); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BarokahJayaSpeed\resources\views/history.blade.php ENDPATH**/ ?>