<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;

class BookingController extends Controller
{
    public function index()
    {
        $bookings = Booking::orderBy('id', 'desc')->get();
        return view('history', compact('bookings'));
    }

    public function updateStatus(Request $request, $id)
    {
        $booking = Booking::findOrFail($id);
        $booking->status = $request->status;
        $booking->save();

        return redirect()->back()->with('success', 'Status booking berhasil diperbarui!');
    }

    public function create()
    {
        return view('booking');
    }

    public function store(Request $request)
    {
        $request->validate([
            'customer_name' => 'required',
            'motor' => 'required',
            'notes' => 'nullable',
        ]);

        Booking::create([
            'customer_name' => $request->customer_name,
            'motor' => $request->motor,
            'notes' => $request->notes,
            'status' => 'DI terima',
        ]);

        return redirect('/history')->with('success', 'Booking berhasil dibuat!');
    }
}
