@extends('layouts.app')
@section('title', 'Sparepart — Barokah Jaya Speed')

@section('content')
<h2 class="section-title">Sparepart Premium</h2>

<div class="grid-container">
  @foreach(range(1, 6) as $i)
  <div class="spare-card">
    <img src="https://via.placeholder.com/150" alt="Sparepart {{ $i }}">
    <h4>Sparepart {{ $i }}</h4>
    <p>Rp {{ number_format(150000 * $i, 0, ',', '.') }}</p>
    <button class="btn-red">Detail</button>
  </div>
  @endforeach
</div>
@endsection
