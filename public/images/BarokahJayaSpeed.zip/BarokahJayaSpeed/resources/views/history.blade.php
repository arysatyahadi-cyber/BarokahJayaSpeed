@extends('layouts.app')
@section('title', 'History — Barokah Jaya Speed')

@section('content')
<h2 class="section-title">History Booking Terbaru</h2>
<div class="history-card">
  <table>
    <thead>
      <tr>
        <th>Nama</th>
        <th>Motor</th>
        <th>No. Polisi</th>
        <th>Keluhan</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      @foreach($bookings as $b)
      <tr>
        <td>{{ $b->nama }}</td>
        <td>{{ $b->motor }}</td>
        <td>{{ $b->nopol }}</td>
        <td>{{ $b->keluhan }}</td>
        <td>{{ $b->status }}</td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>
@endsection
