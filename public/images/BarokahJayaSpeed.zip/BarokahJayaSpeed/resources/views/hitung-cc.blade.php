@extends('layouts.app')
@section('title', 'Hitung CC — Barokah Jaya Speed')

@section('content')
<div class="cc-card">
  <h2>Hitung Kapasitas Mesin (CC)</h2>
  <form>
    <input type="number" id="bore" placeholder="Diameter (mm)">
    <input type="number" id="stroke" placeholder="Langkah (mm)">
    <input type="number" id="cylinder" placeholder="Jumlah Silinder">
    <button type="button" class="btn-red" onclick="hitungCC()">Hitung</button>
  </form>
  <h3 id="hasil"></h3>
</div>

<script>
function hitungCC() {
  let bore = document.getElementById('bore').value;
  let stroke = document.getElementById('stroke').value;
  let cyl = document.getElementById('cylinder').value;
  let cc = (3.14 / 4) * bore * bore * stroke * cyl / 1000;
  document.getElementById('hasil').innerText = `Hasil: ${cc.toFixed(2)} cc`;
}
</script>
@endsection
