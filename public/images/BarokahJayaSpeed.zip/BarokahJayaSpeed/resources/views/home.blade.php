@extends('layouts.layout')
@section('title', 'Home - Barokah Jaya Speed')

@section('content')
<section class="hero">
  <div class="hero-text">
    <h1>Barokah Jaya Speed</h1>
    <p>Bengkel Racing & Service Profesional — Cepat, Presisi, Berkelas!</p>
    <a href="{{ url('/booking') }}" class="btn-red">Booking Sekarang</a>
  </div>
</section>

<section class="history-preview">
  <h2 class="section-title">Riwayat Servis Terbaru</h2>
  <div class="history-card">
    <table>
      <thead>
        <tr>
          <th>Nama Pelanggan</th>
          <th>Motor</th>
          <th>No. Polisi</th>
          <th>Keluhan</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        @forelse ($bookings as $booking)
        <tr>
          <td>{{ $booking->customer_name }}</td>
          <td>{{ $booking->motor }}</td>
          <td>{{ $booking->nopol }}</td>
          <td>{{ $booking->notes }}</td>
          <td>
            <span class="status {{ strtolower(str_replace(' ', '-', $booking->status)) }}">
              {{ $booking->status }}
            </span>
          </td>
        </tr>
        @empty
        <tr>
          <td colspan="5" style="text-align:center;">Belum ada riwayat booking.</td>
        </tr>
        @endforelse
      </tbody>
    </table>
  </div>
</section>
@endsection
